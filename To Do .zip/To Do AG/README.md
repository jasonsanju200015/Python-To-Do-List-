# To Do AG — Individual Project

## Project Summary
To Do AG is a lightweight task manager written in Python. It provides user login, task categories, and CRUD operations for tasks with local persistence (JSON or SQLite). The app can run as a CLI or a simple Tkinter GUI.

## Features
- User login / authentication
- Create, view, edit, delete tasks
- Task categories and due dates
- Mark tasks as complete
- Persistent storage: `storage.json` or `database.db`
- Simple UI (CLI or Tkinter)

## Quick Start
1. Install Python 3.x from https://www.python.org
2. Open the project folder in VS Code: `c:\Users\Sanjeevan\Desktop\To Do AG`
3. (Optional) Create a virtual environment:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```

4. Run the app:

```powershell
python main.py
```

## Project Structure
- `auth.py` — authentication logic
- `database.py` — storage abstraction (JSON/SQLite helpers)
- `main.py` — application entry point
- `task_manager.py` — task CRUD and business logic
- `test_backend.py` — unit tests for backend
- `ui/` — UI modules (`dashboard_window.py`, `login_window.py`, `task_form.py`)

## Data Model (Task)
- `id`: integer or UUID
- `title`: string (required)
- `description`: string (optional)
- `category`: string (optional)
- `due_date`: ISO date string (optional)
- `status`: `pending` | `complete`
- `created_at` / `updated_at`: timestamps
- `owner_id`: user identifier

## Storage
- JSON example file: `storage.json`
- SQLite example DB: `database.db`

## Testing
- Run unit tests (if using pytest):

```powershell
python -m pytest test_backend.py
```

## SRS and Documentation
See the Software Requirements Specification file: `SRS.md`.

## Conversion to PDF (SRS)
To convert `SRS.md` to `SRS.pdf`, you can use Pandoc (if installed):

```powershell
pandoc SRS.md -o SRS.pdf
```

Or use VS Code's markdown preview and "Print to PDF".

## Screenshots
Add screenshots to `docs/screenshots/` (create folder) and reference them here.

## Future Work
- Multi-user support and stronger authentication
- Reminders/notifications
- Sync across devices

---
Author: (Your Name)
Date: December 2025
