from database import get_db_connection

class TaskManager:
    def __init__(self, username):
        self.username = username

    def add_task(self, name, priority, due_date, category):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO tasks (username, name, priority, due_date, category, status)
            VALUES (?, ?, ?, ?, ?, 'Pending')
        ''', (self.username, name, priority, due_date, category))
        conn.commit()
        conn.close()

    def get_tasks(self):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM tasks WHERE username = ?", (self.username,))
        tasks = cursor.fetchall()
        conn.close()
        return [dict(task) for task in tasks]

    def update_task(self, task_id, name, priority, due_date, category):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE tasks 
            SET name = ?, priority = ?, due_date = ?, category = ?
            WHERE id = ? AND username = ?
        ''', (name, priority, due_date, category, task_id, self.username))
        conn.commit()
        conn.close()

    def delete_task(self, task_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM tasks WHERE id = ? AND username = ?", (task_id, self.username))
        conn.commit()
        conn.close()

    def mark_completed(self, task_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE tasks SET status = 'Completed' WHERE id = ? AND username = ?", (task_id, self.username))
        conn.commit()
        conn.close()
