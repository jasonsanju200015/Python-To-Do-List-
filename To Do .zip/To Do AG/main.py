import tkinter as tk
from ui.login_window import LoginWindow
from ui.dashboard_window import DashboardWindow
from database import initialize_database

class ToDoApp:
    def __init__(self):
        self.root = tk.Tk()
        self.current_window = None
        self.show_login()
        
    def show_login(self):
        self.clear_window()
        self.current_window = LoginWindow(self.root, self.show_dashboard)
        
    def show_dashboard(self, username):
        self.clear_window()
        self.current_window = DashboardWindow(self.root, username, self.show_login)
        
    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    initialize_database()
    app = ToDoApp()
    app.run()
