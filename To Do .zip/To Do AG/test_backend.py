import unittest
import os
from database import initialize_database, get_db_connection
from auth import AuthManager
from task_manager import TaskManager

class TestBackend(unittest.TestCase):
    def setUp(self):
        # Use a test database
        self.test_db = "test_database.db"
        import database
        database.DB_NAME = self.test_db
        initialize_database()
        self.auth = AuthManager()
        self.username = "testuser"
        self.password = "password123"
        self.auth.register(self.username, self.password)
        self.tm = TaskManager(self.username)

    def tearDown(self):
        if os.path.exists(self.test_db):
            os.remove(self.test_db)

    def test_login(self):
        self.assertTrue(self.auth.login(self.username, self.password))
        self.assertFalse(self.auth.login(self.username, "wrongpassword"))

    def test_add_task(self):
        self.tm.add_task("Test Task", "High", "2023-12-31", "Work")
        tasks = self.tm.get_tasks()
        self.assertEqual(len(tasks), 1)
        self.assertEqual(tasks[0]['name'], "Test Task")

    def test_update_task(self):
        self.tm.add_task("Old Name", "Low", "2023-01-01", "Personal")
        tasks = self.tm.get_tasks()
        task_id = tasks[0]['id']
        self.tm.update_task(task_id, "New Name", "High", "2023-12-31", "Work")
        updated_task = self.tm.get_tasks()[0]
        self.assertEqual(updated_task['name'], "New Name")
        self.assertEqual(updated_task['priority'], "High")

    def test_delete_task(self):
        self.tm.add_task("To Delete", "Low", "2023-01-01", "Personal")
        tasks = self.tm.get_tasks()
        task_id = tasks[0]['id']
        self.tm.delete_task(task_id)
        self.assertEqual(len(self.tm.get_tasks()), 0)

    def test_mark_completed(self):
        self.tm.add_task("To Complete", "Low", "2023-01-01", "Personal")
        tasks = self.tm.get_tasks()
        task_id = tasks[0]['id']
        self.tm.mark_completed(task_id)
        completed_task = self.tm.get_tasks()[0]
        self.assertEqual(completed_task['status'], "Completed")

if __name__ == '__main__':
    unittest.main()
