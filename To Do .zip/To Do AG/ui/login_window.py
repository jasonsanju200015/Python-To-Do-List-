import tkinter as tk
from tkinter import messagebox
from auth import AuthManager

class LoginWindow:
    def __init__(self, root, on_login_success):
        self.root = root
        self.root.title("To-Do List - Login")
        self.root.geometry("300x250")
        self.on_login_success = on_login_success
        self.auth_manager = AuthManager()

        tk.Label(root, text="Username").pack(pady=5)
        self.username_entry = tk.Entry(root)
        self.username_entry.pack(pady=5)

        tk.Label(root, text="Password").pack(pady=5)
        self.password_entry = tk.Entry(root, show="*")
        self.password_entry.pack(pady=5)

        tk.Button(root, text="Login", command=self.login).pack(pady=5)
        tk.Button(root, text="Register", command=self.register).pack(pady=5)

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        if self.auth_manager.login(username, password):
            self.on_login_success(username)
        else:
            messagebox.showerror("Error", "Invalid credentials")

    def register(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        if not username or not password:
            messagebox.showwarning("Warning", "Fields cannot be empty")
            return
            
        success, message = self.auth_manager.register(username, password)
        if success:
            messagebox.showinfo("Success", message)
        else:
            messagebox.showerror("Error", message)
