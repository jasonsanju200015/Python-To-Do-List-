# Software Requirements Specification (SRS) — To Do AG

## 1. Introduction
### 1.1 Purpose
This SRS describes the functional and non-functional requirements for To Do AG, a simple task-management application for local desktop use.

### 1.2 Scope
To Do AG enables users to authenticate, create and manage tasks with categories and due dates, mark tasks complete, and persist data locally using JSON or SQLite.

## 2. Overall Description
### 2.1 Product Perspective
Standalone desktop application (CLI or Tkinter GUI) written in Python.

### 2.2 User Classes and Characteristics
- End user: non-technical user managing personal tasks.
- Developer: uses project source code for maintenance.

## 3. Functional Requirements
- FR1: Authentication
  - The system shall allow users to log in with a username and password.
  - The system shall validate credentials against stored user records.

- FR2: Task Management
  - FR2.1: Create Task — The system shall allow a logged-in user to create a new task with title, optional description, category, and optional due date.
  - FR2.2: Read Tasks — The system shall display a list of the user's tasks and allow filtering by category and status.
  - FR2.3: Update Task — The system shall allow editing a task's title, description, category, due date, and status.
  - FR2.4: Delete Task — The system shall allow deleting a task.
  - FR2.5: Mark Complete — The system shall allow marking a task as `complete`, updating storage accordingly.

- FR3: Persistence
  - The system shall persist tasks and users to `storage.json` or `database.db` so data is retained between runs.

- FR4: Input Validation
  - The system shall validate required fields (e.g., title) and provide meaningful error messages.

## 4. Non-functional Requirements
- NFR1: Usability — The UI shall be simple and require minimal instructions.
- NFR2: Performance — The system shall respond within 1 second for common operations on small local datasets (<1000 tasks).
- NFR3: Reliability — Data writes shall be atomic to avoid corruption; if using JSON, use safe-write patterns.
- NFR4: Portability — The application shall run on Windows, macOS, and Linux with Python 3.x installed.

## 5. Data Model
Describe the `Task` entity and `User` entity (fields outlined in README).

## 6. External Interfaces
- CLI: text-based menu for all operations.
- GUI: Tkinter windows for login, dashboard, and task form.

## 7. System Architecture
Modular Python code with layers:
- UI layer (`ui/`)
- Application logic (`task_manager.py`, `auth.py`)
- Storage layer (`database.py`)

## 8. Acceptance Criteria
- AC1: A user can log in and add a task that persists after restarting the app.
- AC2: A user can edit and delete tasks.
- AC3: A user can mark tasks complete and see updated status.
- AC4: Input validation prevents empty titles.

## 9. Test Plan (Summary)
- Unit tests for task CRUD and storage functions (`test_backend.py`).
- Manual tests for UI flows: login, add, edit, delete, complete.

## 10. Known Risks and Mitigations
- Risk: JSON concurrency or write failure — Mitigation: use atomic write or SQLite.
- Risk: Missing validation — Mitigation: centralized validation helpers and tests.

## 11. Appendix
- Conversion note: Use Pandoc or VS Code to export this SRS to `SRS.pdf` if a PDF is required.

