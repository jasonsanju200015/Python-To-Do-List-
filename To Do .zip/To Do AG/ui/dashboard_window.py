import tkinter as tk
from tkinter import ttk, messagebox
from task_manager import TaskManager
from ui.task_form import TaskForm

class DashboardWindow:
    def __init__(self, root, username, on_logout):
        self.root = root
        self.username = username
        self.on_logout = on_logout
        self.task_manager = TaskManager(username)
        
        self.root.title(f"To-Do List - {username}")
        self.root.geometry("600x400")
        
        # Top Bar
        top_frame = tk.Frame(root)
        top_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Button(top_frame, text="Add Task", command=self.open_add_task).pack(side=tk.LEFT)
        tk.Button(top_frame, text="Logout", command=self.logout).pack(side=tk.RIGHT)
        
        # Task List (Treeview)
        columns = ("ID", "Name", "Priority", "Due Date", "Category", "Status")
        self.tree = ttk.Treeview(root, columns=columns, show="headings")
        
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=80)
        
        self.tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Action Buttons
        btn_frame = tk.Frame(root)
        btn_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Button(btn_frame, text="Edit", command=self.edit_task).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Delete", command=self.delete_task).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Mark Completed", command=self.mark_completed).pack(side=tk.LEFT, padx=5)
        
        self.load_tasks()

    def load_tasks(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        tasks = self.task_manager.get_tasks()
        for task in tasks:
            self.tree.insert("", tk.END, values=(
                task['id'], task['name'], task['priority'], 
                task['due_date'], task['category'], task['status']
            ))

    def open_add_task(self):
        TaskForm(self.root, self.save_new_task)

    def save_new_task(self, name, priority, due_date, category):
        self.task_manager.add_task(name, priority, due_date, category)
        self.load_tasks()

    def edit_task(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showwarning("Warning", "Select a task to edit")
            return
            
        item = self.tree.item(selected_item)
        task_id = item['values'][0]
        task_data = {
            'name': item['values'][1],
            'priority': item['values'][2],
            'due_date': item['values'][3],
            'category': item['values'][4]
        }
        
        TaskForm(self.root, lambda n, p, d, c: self.save_edited_task(task_id, n, p, d, c), task=task_data)

    def save_edited_task(self, task_id, name, priority, due_date, category):
        self.task_manager.update_task(task_id, name, priority, due_date, category)
        self.load_tasks()

    def delete_task(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showwarning("Warning", "Select a task to delete")
            return
            
        if messagebox.askyesno("Confirm", "Are you sure you want to delete this task?"):
            task_id = self.tree.item(selected_item)['values'][0]
            self.task_manager.delete_task(task_id)
            self.load_tasks()

    def mark_completed(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showwarning("Warning", "Select a task to mark as completed")
            return
            
        task_id = self.tree.item(selected_item)['values'][0]
        self.task_manager.mark_completed(task_id)
        self.load_tasks()

    def logout(self):
        self.on_logout()
