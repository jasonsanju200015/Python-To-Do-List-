import tkinter as tk
from tkinter import ttk, messagebox

class TaskForm(tk.Toplevel):
    def __init__(self, parent, on_save, task=None):
        super().__init__(parent)
        self.title("Add/Edit Task")
        self.geometry("300x300")
        self.on_save = on_save
        self.task = task

        tk.Label(self, text="Task Name").pack(pady=2)
        self.name_entry = tk.Entry(self)
        self.name_entry.pack(pady=2)

        tk.Label(self, text="Priority").pack(pady=2)
        self.priority_var = tk.StringVar(value="Low")
        self.priority_combo = ttk.Combobox(self, textvariable=self.priority_var, values=["High", "Low"])
        self.priority_combo.pack(pady=2)

        tk.Label(self, text="Due Date (YYYY-MM-DD)").pack(pady=2)
        self.date_entry = tk.Entry(self)
        self.date_entry.pack(pady=2)

        tk.Label(self, text="Category").pack(pady=2)
        self.category_var = tk.StringVar(value="Personal")
        self.category_combo = ttk.Combobox(self, textvariable=self.category_var, values=["Work", "Personal", "Study", "Other"])
        self.category_combo.pack(pady=2)

        if task:
            self.name_entry.insert(0, task['name'])
            self.priority_var.set(task['priority'])
            self.date_entry.insert(0, task['due_date'])
            self.category_var.set(task['category'])

        tk.Button(self, text="Save", command=self.save).pack(pady=10)

    def save(self):
        name = self.name_entry.get()
        priority = self.priority_var.get()
        due_date = self.date_entry.get()
        category = self.category_var.get()

        if not name or not due_date:
            messagebox.showwarning("Warning", "Name and Due Date are required")
            return

        self.on_save(name, priority, due_date, category)
        self.destroy()
